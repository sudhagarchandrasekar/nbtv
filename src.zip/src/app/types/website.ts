export interface Website {
    logo: string;
    url: string;
    color: string;
}
