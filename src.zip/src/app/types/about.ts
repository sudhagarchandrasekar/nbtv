export interface About {
    logo: string;
    line1: string;
    line2: string;
}
