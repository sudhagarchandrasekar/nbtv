export interface SocialMedia {
    name: string;
    logo: string;
    url: string;
    color: string;
}
