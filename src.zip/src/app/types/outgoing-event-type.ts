export enum OutgoingEventType {
    EMAIL = 0,
    PHONE = 1,
    WEBSITE = 2,
    WHATSAPP = 3
}
