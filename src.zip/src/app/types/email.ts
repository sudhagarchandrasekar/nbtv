export interface Email {
    logo: string;
    id: string;
    color: string;
}
