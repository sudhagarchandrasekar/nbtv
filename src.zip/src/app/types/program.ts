export interface Program {
    time: string;
    name: string;
}
