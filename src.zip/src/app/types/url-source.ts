export interface UrlSource {
    name: string;
    url: string;
    embeddable: boolean;
}
