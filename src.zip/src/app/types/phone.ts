export interface Phone {
    logo: string;
    number: string;
    whatsapp: boolean;
    color: string;
}
