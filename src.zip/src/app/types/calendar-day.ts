export interface CalendarDay {
    label: string;
    date: Date;
    day: number;
}
