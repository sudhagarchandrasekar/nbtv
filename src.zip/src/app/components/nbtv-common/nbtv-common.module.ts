import { EmailComposer } from '@awesome-cordova-plugins/email-composer';
import { LiveTvComponent } from './../live-tv/live-tv.component';
import { ProgramScheduleComponent } from './../program-schedule/program-schedule.component';
import { ProfileComponent } from './../profile/profile.component';
import { MenuContentComponent } from './../menu-content/menu-content.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  exports: [ProfileComponent, MenuContentComponent, ProgramScheduleComponent, LiveTvComponent ],
  declarations: [ProfileComponent, MenuContentComponent, ProgramScheduleComponent, LiveTvComponent ],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    HttpClientModule
  ],
  providers: []
})
export class NbtvCommonModule { }
