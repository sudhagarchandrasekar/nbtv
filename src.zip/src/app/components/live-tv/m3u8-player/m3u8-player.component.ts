import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m3u8-player',
  templateUrl: './m3u8-player.component.html',
  styleUrls: ['./m3u8-player.component.scss'],
})
export class M3u8PlayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
