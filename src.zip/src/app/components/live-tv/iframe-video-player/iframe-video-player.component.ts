import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iframe-video-player',
  templateUrl: './iframe-video-player.component.html',
  styleUrls: ['./iframe-video-player.component.scss'],
})
export class IframeVideoPlayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
