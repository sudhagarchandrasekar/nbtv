import { UrlSource } from './../../types/url-source';
import { AppData } from './../../types/app-data';
import { AppStateService } from './../../app-state.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ScreenOrientation } from '@awesome-cordova-plugins/screen-orientation/ngx';
import { StreamingMedia, StreamingVideoOptions } from '@awesome-cordova-plugins/streaming-media/ngx';


@Component({
  selector: 'app-live-tv',
  templateUrl: './live-tv.component.html',
  styleUrls: ['./live-tv.component.scss'],
})
export class LiveTvComponent implements OnInit {

  @ViewChild('video_player_iframe') iframeVideoPlayerComponent: ElementRef;

  appData: AppData = null;
  isVideoLoaded = false;
  selectedSource: UrlSource = null;

  constructor(private appStateService: AppStateService,
    private domSanitizer: DomSanitizer,
    private screenOrientation: ScreenOrientation,
    private streamingMedia: StreamingMedia) { }

  ngOnInit() {
    this.appData = this.appStateService.getAppData();
    this.selectedSource = this.appData.liveTvURL[0];
    this.initializeScreenOrientation();
  }

  changeLiveTVSource(event) {
    console.dir(event);
    this.setUpLiveTVPlayer(event.detail.value);
  }

  setUpLiveTVPlayer(source: UrlSource) {
    this.selectedSource = source;
    if(source.embeddable === false) {
      this.setUpHlsSource();
    }
    this.ionViewDidEnter();
  }

  getSanitizedURL(url: string) {
    console.log(url);
    return this.domSanitizer.bypassSecurityTrustResourceUrl(url);
  }

  ionViewDidEnter() {
    console.dir(this.iframeVideoPlayerComponent);
    const iframe = this.iframeVideoPlayerComponent.nativeElement;
    iframe.addEventListener('load', ()=> {
      console.log('iframe loaded');
    });
  }

  setUpHlsSource() {
    const videoOptions: StreamingVideoOptions = this.getStreamingVideoOptions();
    this.streamingMedia.playVideo(this.selectedSource.url,videoOptions);
  }

  getStreamingVideoOptions(): StreamingVideoOptions {
    const videoOptions: StreamingVideoOptions = {
      controls: true,
      orientation: 'landscape',
      shouldAutoClose: true,
      errorCallback: (err) => {
        console.error(err);
      },
      successCallback: () => {
        // nothing to do
        console.log('yay!!');
      }
    };
    return videoOptions;
  }


  /** Screen Orientation changes */
  changeToLandscape() {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.LANDSCAPE);
  }

  changeToPortait() {
    this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
  }

  initializeScreenOrientation() {
    this.screenOrientation.onChange().subscribe((value)=> {
      console.dir(value);
      console.dir(this.screenOrientation.type);
      this.screenOrientation.unlock();
    });
  }



}
