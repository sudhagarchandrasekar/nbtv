import { Schedule } from './types/schedule';
import { AppData } from './types/app-data';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppStateService {

  private appData: AppData = null;
  private programSchedule: Schedule[] = [];

  constructor() { }

  getAppData(): AppData {
    return this.appData;
  }

  setAppData(appData: AppData) {
    this.appData = appData;
  }

  getProgramSchedule(): Schedule[] {
    return this.programSchedule;
  }

  setProgramSchdule(schedule: Schedule[]) {
    this.programSchedule = schedule;
  }

}
